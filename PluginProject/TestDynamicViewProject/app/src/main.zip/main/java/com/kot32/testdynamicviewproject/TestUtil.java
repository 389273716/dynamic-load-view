package com.kot32.testdynamicviewproject;

/**
 * Created by kot32 on 16/9/20.
 */
public class TestUtil {
    public static int getTestInteger(){
        return 1080;
    }
}
